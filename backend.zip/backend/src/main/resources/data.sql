INSERT INTO member (name, age) VALUES ('Bill', 10);
INSERT INTO member (name, age) VALUES ('Kz', 5);
